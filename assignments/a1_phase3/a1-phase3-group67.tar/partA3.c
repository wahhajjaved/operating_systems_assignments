/*
* @author Wahhaj Javed, muj975, 11135711
* @author Nakhba Mubashir, epl482, 11317060
* @date 2024-09-22
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>

#include <square.h>

pthread_key_t tlsKey; /*thread local storage*/

int getIndex() {
	int index;
	index = *(int*)pthread_getspecific(tlsKey);
	return index;
}

void* tmain(void* lpParam) {
	int32_t n, index;
	int32_t* params;
    uint64_t elapsedTime;
	struct timespec startTime, endTime;
	

	params = (int32_t*)lpParam;
	index = params[0];
	n = params[1];
    
	pthread_setspecific(tlsKey, (void*)&index);

    clock_gettime(CLOCK_MONOTONIC, &startTime);
	Square(n);
	clock_gettime(CLOCK_MONOTONIC, &endTime);

	elapsedTime = 1000000000L * (endTime.tv_sec - startTime.tv_sec) + 
        endTime.tv_nsec - startTime.tv_nsec;
	elapsedTime = elapsedTime / 1000;
    printf("Thread %d finished. "
        "Square called %d times. "
        "Thread ran for %lu microseconds.\n",
		index, pSquareCount[index], elapsedTime);
	
	return 0;

}


int main(int argc, char* argv[]) {
	int32_t threads, size, deadline, *args;
	pthread_t *threadIDs;
	int i;
	int32_t** threadParams;

	args = parseArgs(argc, argv);
    if (args == NULL){
        return 1;
    }
    threads = args[0];
	deadline = args[1];
	size = args[2];

	pthread_key_create(&tlsKey, NULL);
	
	threadIDs = malloc(sizeof(pthread_t) * threads);
	pSquareCount = (int32_t *)calloc(threads, sizeof(int32_t));
	pStartTime = (int64_t *)calloc(threads, sizeof(int64_t));
	
	
	threadParams = malloc(threads * sizeof(int32_t*));
	for(i=0; i<threads; i++) {
		int r;
		threadParams[i] = malloc(sizeof(int32_t) * 2);
		threadParams[i][0] = i;
		threadParams[i][1] = size;
		
		r = pthread_create(
			&threadIDs[i],
			NULL,
			tmain,
			threadParams[i]
		);

		if (r != 0) {
			printf("pthread_create failed. Error: %u\n", r);
			return 1;
		}
	}


	sleep(deadline);
	stopSquare = 1;
	

	return 0;
}