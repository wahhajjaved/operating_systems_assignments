/*
* @author Wahhaj Javed, muj975, 11135711
* @author Nakhba Mubashir, epl482, 11317060
* @date 2024-10-03
*/

#include <stdio.h>

int main() {
    printf("Dummy file for checking makefile recipe that compiles "
        "the marker's list test file.\n"
    );
    
    return 0;
}