/*
 *@author Wahhaj Javed, muj975, 11135711
 *@author Nakhba Mubashir, epl482, 11317060
 */


#include <stdio.h>
#include <os.h>
#include <stdlib.h>
#include <standards.h>

void init(void);
int left(int phil);
int right(int phil);
void checkIfReady(int phil);
void getChopstick(int phil);
void putChopstick(int phil);
