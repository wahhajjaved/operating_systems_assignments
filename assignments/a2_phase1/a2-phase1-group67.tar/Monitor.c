/*
 *@author Wahhaj Javed, muj975, 11135711
 *@author Nakhba Mubashir, epl482, 11317060
 */

#include "Monitor.h"


void MonEnter(void) {}

void MonLeave(void) {}

void MonWait(int signal) {}

void MonSignal(int signal) {}
