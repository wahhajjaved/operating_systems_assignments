
extern int shopOpen;

int init();
void customerThread();
void barberThread();