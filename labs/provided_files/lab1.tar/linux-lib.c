/* NAME:
   NSID:
   Student Number:

   CMPT 332 Term 1 2020

   Lab 1

   September 10, 2020
*/

#include <stdio.h>
#include <stdlib.h>

#include <lab1.h>

int myFunc(int param1)
{
  /* Only uncomment next line for debugging */
  /*  printf("got to func1 with params %d and %s\n", param1, param2); */

  return (param1 * (param1 -1));
  
}


  
