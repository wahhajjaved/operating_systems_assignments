/* NAME:
   NSID:
   Student Number:

   CMPT 332 Term 1 2018

   Lab 1

   September 10, 2018
   Modified September 9, 2020
*/

#ifndef CMPT332_LAB1_H_
#define CMPT332_LAB1_H_

int myFunc(int);

#endif /* CMPT332_LAB1_H_ */
